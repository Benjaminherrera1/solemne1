package com.mycompany.revista;
import java.util.Scanner;


public class Revista {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        String Nombre = "", Autor ="", Demografia ="";
        int F_Publicacion = 0, V_Trimestrales = 0, i=1;
        
        for(int n=1; n!=6; n++){
            System.out.println("Manga "+n+ ":");
            Manga objeto1 = new Manga(Nombre, Autor, Demografia, F_Publicacion, V_Trimestrales);
            System.out.println("Ingrese el nombre del Manga: ");
            Nombre = leer.next();
            System.out.println("Ingrese el Autor del Manga: ");
            Autor = leer.next();
            System.out.println("Ingrese la demografia del Manga: ");
            Demografia = leer.next();
            System.out.println("Ingrese la fecha de publicacion del Manga: ");
            F_Publicacion = leer.nextInt();
            System.out.println("Ingrese las ventas trimestrales del Manga: ");
            V_Trimestrales = leer.nextInt();
            
            Manga objeto2 = new Manga(Nombre, Autor, Demografia, F_Publicacion, V_Trimestrales);
            Manga objeto3 = new Manga(Nombre, Autor, Demografia, F_Publicacion, V_Trimestrales);
            Manga objeto4 = new Manga(Nombre, Autor, Demografia, F_Publicacion, V_Trimestrales);
            Manga objeto5 = new Manga(Nombre, Autor, Demografia, F_Publicacion, V_Trimestrales);
            
            i++;
            
            if(i==6){
                System.out.println(objeto1.Mostrar_Datos());
                System.out.println(objeto2.Mostrar_Datos());
                System.out.println(objeto3.Mostrar_Datos());
                System.out.println(objeto4.Mostrar_Datos());
                System.out.println(objeto5.Mostrar_Datos());
                
                if(objeto1.getV_Trimestrales() > objeto2.getV_Trimestrales()){
                    System.out.println("El manga 1 vendio mas");
                }
                
            
                if (objeto2.getV_Trimestrales() > objeto3.getV_Trimestrales()){
                    System.out.println("El manga 2 vendio mas");                    
                        
                }
                
                if(objeto3.getV_Trimestrales() > objeto4.getV_Trimestrales()){
                    System.out.println("El manga 3 vendio mas");
                    
                }
                
                if(objeto4.getV_Trimestrales() > objeto5.getV_Trimestrales()){
                    System.out.println("El manga 4 vendio mas");
                    
                }
                
                else {
                    System.out.println("El manga 5 vendio mas");
                
                }
             
                 
                                                   
                
                
                
                
                    
                    
                
            }
        }
    
    } 
}          
                
                
              
        
        
   
            
        
        

               