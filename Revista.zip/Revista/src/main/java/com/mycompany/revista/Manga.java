/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.revista;

/**
 *
 * @author mplab4.pc23
 */
public class Manga {
    
    private String Nombre, Autor, Demografia;
    private int F_Publicacion, V_Trimestrales;

    public Manga(String Nombre, String Autor, String Demografia, int F_Publicacion, int V_Trimestrales) {
        this.Nombre = Nombre;
        this.Autor = Autor;
        this.Demografia = Demografia;
        this.F_Publicacion = F_Publicacion;
        this.V_Trimestrales = V_Trimestrales;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String Autor) {
        this.Autor = Autor;
    }

    public String getDemografia() {
        return Demografia;
    }

    public void setDemografia(String Demografia) {
        this.Demografia = Demografia;
    }

    public int getF_Publicacion() {
        return F_Publicacion;
    }

    public void setF_Publicacion(int F_Publicacion) {
        this.F_Publicacion = F_Publicacion;
    }

    public int getV_Trimestrales() {
        return V_Trimestrales;
    }

    public void setV_Trimestrales(int V_Trimestrales) {
        this.V_Trimestrales = V_Trimestrales;
    }
    
    public String Mostrar_Datos(){
        
        String texto = "El manga "+this.Nombre+" del autor "+this.Autor+ " publicado en "+this.F_Publicacion+" tiene demografia " +this.getDemografia();
        return texto;
    
    
    }

    
}
